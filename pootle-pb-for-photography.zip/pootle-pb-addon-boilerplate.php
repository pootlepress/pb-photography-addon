<?php
/*
Plugin Name: pootle page builder for photography
Plugin URI: http://pootlepress.com/
Description: Boilerplate for fast track Pootle Page Builder Addon Development
Author: Shramee
Version: 0.1.0
Author URI: http://shramee.com/
*/

/** Including Main Plugin class */
require_once 'class-pootle-pb-for-photography.php';
/** Intantiating main plugin class */
pootle_page_builder_for_photography::instance();